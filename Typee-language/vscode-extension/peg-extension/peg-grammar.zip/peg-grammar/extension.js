// PEG grammar navigation: go to definition, references, occurrence highlight, outline.
const vscode = require('vscode');

const WORD = /[A-Za-z_][A-Za-z0-9_]*/;

// Blank out comments, '...' strings and [...] classes so they are never matched as rule names.
function mask(line) {
  let out = '';
  let i = 0;
  while (i < line.length) {
    const c = line[i];
    if (c === '#' && line[i + 1] === '#') {
      out += ' '.repeat(line.length - i);
      break;
    }
    if (c === "'" || c === '[') {
      const close = c === "'" ? "'" : ']';
      let j = i + 1;
      while (j < line.length && line[j] !== close) {
        if (line[j] === '\\') j++;
        j++;
      }
      const end = Math.min(j + 1, line.length);
      out += ' '.repeat(end - i);
      i = end;
    } else {
      out += c;
      i++;
    }
  }
  return out;
}

function nameAt(doc, pos) {
  const range = doc.getWordRangeAtPosition(pos, WORD);
  if (!range) return null;
  const masked = mask(doc.lineAt(pos.line).text);
  if (masked[range.start.character] === ' ') return null; // inside comment/string/class
  return { name: doc.getText(range), range };
}

function occurrences(doc, name) {
  const re = new RegExp(`(?<![A-Za-z0-9_])${name}(?![A-Za-z0-9_])`, 'g');
  const result = [];
  for (let l = 0; l < doc.lineCount; l++) {
    const masked = mask(doc.lineAt(l).text);
    let m;
    while ((m = re.exec(masked)) !== null) {
      result.push(new vscode.Range(l, m.index, l, m.index + name.length));
    }
  }
  return result;
}

function definitions(doc) {
  const defs = [];
  const re = /^(\s*)([A-Za-z_][A-Za-z0-9_]*)(\s*)<-/;
  for (let l = 0; l < doc.lineCount; l++) {
    const m = re.exec(mask(doc.lineAt(l).text));
    if (m) {
      const start = m[1].length;
      defs.push({
        name: m[2],
        range: new vscode.Range(l, start, l, start + m[2].length),
        line: l,
      });
    }
  }
  return defs;
}

function activate(context) {
  const sel = { language: 'peg' };

  context.subscriptions.push(
    vscode.languages.registerDefinitionProvider(sel, {
      provideDefinition(doc, pos) {
        const hit = nameAt(doc, pos);
        if (!hit) return null;
        return definitions(doc)
          .filter((d) => d.name === hit.name)
          .map((d) => new vscode.Location(doc.uri, d.range));
      },
    }),

    vscode.languages.registerReferenceProvider(sel, {
      provideReferences(doc, pos, ctx) {
        const hit = nameAt(doc, pos);
        if (!hit) return null;
        const defRanges = definitions(doc)
          .filter((d) => d.name === hit.name)
          .map((d) => d.range.start.line + ':' + d.range.start.character);
        return occurrences(doc, hit.name)
          .filter(
            (r) =>
              ctx.includeDeclaration ||
              !defRanges.includes(r.start.line + ':' + r.start.character)
          )
          .map((r) => new vscode.Location(doc.uri, r));
      },
    }),

    // Powers occurrence highlighting; F7 / Shift+F7 walk through these highlights.
    vscode.languages.registerDocumentHighlightProvider(sel, {
      provideDocumentHighlights(doc, pos) {
        const hit = nameAt(doc, pos);
        if (!hit) return null;
        return occurrences(doc, hit.name).map(
          (r) => new vscode.DocumentHighlight(r, vscode.DocumentHighlightKind.Read)
        );
      },
    }),

    // Outline / Ctrl+Shift+O listing of rules.
    vscode.languages.registerDocumentSymbolProvider(sel, {
      provideDocumentSymbols(doc) {
        return definitions(doc).map(
          (d) =>
            new vscode.DocumentSymbol(
              d.name,
              '',
              vscode.SymbolKind.Function,
              doc.lineAt(d.line).range,
              d.range
            )
        );
      },
    })
  );
}

function deactivate() {}

module.exports = { activate, deactivate };
